<?php
	session_start();
	if(isset($_SESSION['logado']) && $_SESSION['logado']){
		header('Location: banco.php');
	}
?>
<html>
	<head>
		<title>Login</title>
		<meta charset="utf-8">
	</head>
	<body>
		<form action="" method="post">
			<fieldset><legend>Página de Login</legend>
			<label>Selecione o vendedor:</label>
			<select name="user" autofocus>
				<option>Selecione um usuário...</option>
				<option value="Dawid">Dáwid</option>
				<option value="Lucas">Lucas</option>
				<option value="Raiela">Raiela</option>
			</select><br>
			<label>Senha :</label>
			<input type="password" name="password" required>
			<input type="submit" name="acessar" value="LOGIN">
			</fieldset>
		</form>
	</body>
</html>

<?php
	$flag = true;
	if(isset($_POST['acessar'])){
		$nome = $_POST['user'];
		$senha = $_POST['password'];
		$login[0]['username'] = "Dawid";
		$login[0]['password'] = "wid123";
		$login[1]['username'] = "Lucas";
		$login[1]['password'] = "luc123";
		$login[2]['username'] = "Raiela";
		$login[2]['password'] = "rai123";
		
		for($i = 0; $i < count($login);$i++){
				if(!empty($nome) && !empty($senha)){
					if($nome == $login[$i]['username'] && $senha == $login[$i]['password']){
						session_start();
						$_SESSION['usuario'] = $nome;
						$_SESSION['logado'] = true;
						header('Location: banco.php');
					}else{
						if($flag){
							echo "<script>alert('Usuário/Senha incorretos!');</script>";
						}
						$flag=false;
					}
				}
			
		}
		
	}
?>