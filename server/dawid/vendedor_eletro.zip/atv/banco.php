<?php
	session_start();
	if(!isset($_SESSION['logado'])){
		header('Location: index.php');
	}
?>
<html>
	<head>
		<title>Principal - Produtos</title>
		<style>
			.conteudo{
				display: block;
				width: 60%;
				margin: 5em auto;
			}
			form{
				text-align: center;
			}
			table{
				width: 100%;
				text-align: center;
				border-collapse: collapse;
			}
			table td, table th{
				border: 1px solid black;
				padding: 10px;
			}
			table td{
				background-color: #ddd;
			}
		</style>
	</head>
	<body>
		<h2>Bem vindo, <?=ucwords($_SESSION['usuario'])?> <a href="?func=logout">Sair</a></h2>
		<div class="conteudo">
			<form action="?func=prod" method="post">
			<fieldset><legend>Lista de produtos</legend>
				<label>Selecione o produto:</label><br>
				<select name="prod">
					<option>Selecione</option>
					<option value="fogao">Fogão</option>
					<option value="geladeira">Geladeira</option>
					<option value="micro">Microondas</option>
					<option value="tv">Televisão</option>
				</select>
				<input type="submit" name="cons" value="Consultar">
				</fieldset>
			</form>
		</div>
		<div class="conteudo">
			<?php
				if(isset($_GET['func'])){
					$pag = $_GET['func'];
					include $pag.".php";
				}
			?>
		</div>
			
	</body>
</html>