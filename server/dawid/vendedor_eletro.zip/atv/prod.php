<table>
	<tr>
		<th>PRODUTO</th>
		<th>DESCRIÇÃO</th>
	</tr>
	<tr>
<?php
	$p = $_POST['prod'];
	switch($p){
		case 'fogao':
		?>
		<td>Fogão</td>
		<td>Fogão 4 bocas continental</td>
		<?php
			break;
		
		case 'tv':
		?>
		<td>Televisão</td>
		<td></td>
		<?php		
			break;
			
		case 'geladeira':
		?>
		<td>Geladeira</td>
		<td></td>
		<?php
			break;
			
		case 'micro':
		?>
		<td>Microondas</td>
		<td></td>
		<?php
			break;
		
		default:
			
			break;
	}
?>
	</tr>
</table>