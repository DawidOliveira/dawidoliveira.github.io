-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: friendly
-- ------------------------------------------------------
-- Server version	5.7.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `perguntas`
--

DROP TABLE IF EXISTS `perguntas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `perguntas` (
  `codpergunta` int(11) NOT NULL AUTO_INCREMENT,
  `descpergunta` text NOT NULL,
  `cod_catperg` int(11) NOT NULL,
  PRIMARY KEY (`codpergunta`),
  KEY `cod_catperg` (`cod_catperg`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `perguntas`
--

LOCK TABLES `perguntas` WRITE;
/*!40000 ALTER TABLE `perguntas` DISABLE KEYS */;
INSERT INTO `perguntas` VALUES (1,'Mantém bom relacionamento com os colegas.',1),(2,'Mantém bom relacionamento com os professores.',1),(3,'Mantém bom relacionamento com  o articulador pedagógico.',1),(4,'Segue as regras estabelecidas na instituição.',1),(5,'Sabe ouvir as outras pessoas.',1),(6,'Espera a sua vez de falar.',1),(7,'Aceita reclamações e críticas necessárias.',1),(8,'Transmite recados.',1),(9,'Sabe dar oportunidade de voz aos colegas.',1),(10,'Toma decisão.',1),(11,'Justifica suas ações/atos.',1),(12,'Sabe integrar com o(s) grupo(s).',1),(13,'Habitualmente fica isolado.',1),(14,'Sabe compartilhar.',1),(15,'Fala palavras indevidas em momentos inapropriados.',1),(16,'Arruma suas coisas.',1),(17,'Consegue responsabilizar-se por seus materiais.',1),(18,'Consegue permanecer em sala espontaneamente.',1),(19,'Apresenta traços de hiperatividade.',2),(20,'Apresenta Hipoatividade.',2),(21,'Emocionalmente instável.',2),(22,'Ações de autodestruição.',2),(23,'Chora ou sorri em horários não pertinentes.',2),(24,'Tenta contato físico com colegas e professores sem autorização.',2),(25,'Recusa contato físico.',2),(26,'Fala palavras inapropriadas.',2),(27,'Compromete a ordem da classe.',2),(28,'É alegre.',3),(29,'É agressivo.',3),(30,'Precisa ser continuamente supervisionado.',3),(31,'Demonstra interesse por coisas novas.',3),(32,'Concentra atenção.',3),(33,'Quando estimulado, dá retorno imediato em relação à orientação.',3),(34,'Cumpre com sua responsabilidade pedagógica: \nentrega de trabalhos/realização de provas/seminários.',4),(35,'Faz as atividades encaminhadas para casa.',4),(36,'Relização dos trabalhos individualmente (oriundos de casa).',4),(37,'Participa dos trabalhos em equipe.',4),(38,'Inicia, persevera e conclui suas tarefas.',4),(39,'Cumpre com a realização dos trabalhos coletivamente.',4),(40,'Apresenta sugestões próprias.',4),(41,'Utiliza de maneira variada os materiais pedagógicos para manuseio em sala.',4),(42,'Interage nas aulas em relação ao conteúdo apresentado.',4),(43,'Tem \"autonomia\" para realizar as atividades propostas em sala.',4),(44,'Para realizar as tarefas pedagógicas, depende exclusivamente de seu articulador.',4),(45,'Tem bom desempenho nas matérias de humanas.',4),(46,'Tem iniciativa para perguntar.',4),(47,'Tem domínio na escrita.',4),(48,'Tem bom desempenho nas matérias de exatas.',4),(49,'Tem bom desempenho nas matérias das Ciências da Naturalidade.',4),(50,'Tem bom desempenho nas matérias de Linguagem e Códigos.',4),(51,'Fornece atenção individualizada.',5),(52,'Ajuda o aluno quando necessário.',5),(53,'Integra o aluno no grupo.',5),(54,'Encoraja o aluno.',5),(55,'Repete conteúdos.',5),(56,'Permite saída da sala.',5),(57,'Muda o que havia planejamento.',5),(58,'Faz planejamento diferenciado para incluir o aluno.',5),(59,'Organiza materiais diferenciados para adequar a condição ao aluno.',5);
/*!40000 ALTER TABLE `perguntas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-05 21:24:04
