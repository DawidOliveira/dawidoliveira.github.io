-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 02-Jan-2018 às 14:41
-- Versão do servidor: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ifriendly`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `aluno`
--

CREATE TABLE `aluno` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `idade` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `aluno`
--

INSERT INTO `aluno` (`id`, `nome`, `idade`) VALUES
(1, 'Dáwid Silva Oliveira', 18),
(2, 'Teste da Silva', 15);

-- --------------------------------------------------------

--
-- Estrutura da tabela `aspec`
--

CREATE TABLE `aspec` (
  `id` int(11) NOT NULL,
  `fk_cod` int(11) DEFAULT NULL,
  `titulo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `aspec`
--

INSERT INTO `aspec` (`id`, `fk_cod`, `titulo`) VALUES
(1, 3, 'É alegre'),
(2, 3, 'É agressivo'),
(3, 3, 'Precisa ser continuamente supervisionado'),
(4, 3, 'Demonstra interesse por coisas novas'),
(5, 3, 'Concentra atenção'),
(6, 3, 'Quando estimulado, dá retorno imediato em relação a orientação'),
(7, 1, 'Mantém bom relacionamento com os colegas'),
(8, 1, 'Mantém bom relacionamento com os professores'),
(9, 1, 'Mantém bom relacionamento com o articulador pedagógico'),
(10, 1, 'Segue as regras estabelecidas na instituição'),
(11, 1, 'Sabe ouvir outras pessoas'),
(12, 1, 'Espera a sua vez de falar'),
(13, 1, 'Aceita reclamações e críticas necessárias'),
(14, 1, 'Transmite recados'),
(15, 1, 'Sabe dar oportunidade de voz aos colegas'),
(16, 1, 'Toma decisão'),
(17, 1, 'Justifica suas ações/atos'),
(18, 1, 'Sabe integrar com os grupos'),
(19, 1, 'Habitualmente fica isolado'),
(20, 1, 'Sabe compartilhar'),
(22, 1, 'Sabe usar o banheiro sozinho'),
(23, 1, 'Fala palavras indevidas em momentos inapropriados'),
(24, 1, 'Arruma suas coisas'),
(25, 1, 'Consegue responsabilizar-se por seus materiais'),
(26, 1, 'Consegue permanecer em sala espontâneamente'),
(27, 2, 'Apresenta traços de hiperatividade'),
(28, 2, 'Apresenta hipoatividade'),
(29, 2, 'Emocionalmente instável'),
(30, 2, 'Ações de autodestruição'),
(31, 2, 'Chora ou sorri em horários não pertinentes'),
(32, 2, 'Tenta contato físico com colegas e professores sem autorização'),
(33, 2, 'Recusa contato físico'),
(34, 2, 'Fala palavras inapropriadas'),
(35, 2, 'Compromete a ordem da sala'),
(36, 4, 'Cumpre com sua responsabilidade pedagógica (entrega de trabalho, realização das provas, seminários)'),
(37, 4, 'Faz as atividades encaminhadas para casa'),
(38, 4, 'Realiza os trabalhos individualmente (oriundos de casa)'),
(39, 4, 'Participa dos trabalhos em equipe'),
(40, 4, 'Inicia, persevera e conclui suas tarefas'),
(41, 4, 'Cumpre com a realização dos trabalhos coletivamente'),
(42, 4, 'Apresenta sugestões próprias'),
(43, 4, 'Utiliza de maneira variada os materiais pedagógicos para manuseio em sala'),
(44, 4, 'Interage nas aulas em relação ao conteúdo apresentado'),
(45, 4, 'Tem \"autonomia\" para realizar as atividades propostas em sala'),
(46, 4, 'Para realizar as tarefas pedagógicas, depende exclusivamente do seu articulador'),
(47, 4, 'Tem bom desempenho nas matérias de humanas'),
(48, 4, 'Tem iniciativa para perguntar'),
(49, 4, 'Tem domínio na escrita'),
(50, 4, 'Tem bom desempenho nas matérias exatas'),
(51, 4, 'Tem bom desempenho nas matérias das Ciências da Natureza'),
(52, 4, 'Tem bom desempenho nas materiais de Linguagens e Códigos'),
(53, 5, 'Fornece atenção individualizada'),
(54, 5, 'Ajuda o aluno quando necessário'),
(55, 5, 'Integra o aluno no grupo'),
(56, 5, 'Encoraja o aluno'),
(57, 5, 'Repete conteúdos'),
(58, 5, 'Permite saída da sala'),
(59, 5, 'Muda o que havia planejado'),
(60, 5, 'Faz planejamento diferenciado para incluir o aluno'),
(61, 5, 'Organiza materiais diferenciados para adequar a condição do aluno'),
(62, 5, 'Produz avaliações diferenciadas');

-- --------------------------------------------------------

--
-- Estrutura da tabela `quest`
--

CREATE TABLE `quest` (
  `cod` int(11) NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `pagname` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `quest`
--

INSERT INTO `quest` (`cod`, `titulo`, `pagname`) VALUES
(1, 'Acompanhamento do desenvolvimento social', 'aspecsocial.php'),
(2, 'Acompanhamento do desenvolvimento comportamental', 'aspeccomport.php'),
(3, 'Acompanhamento do desenvolvimento afetivo', 'aspecafetivo.php'),
(4, 'Acompanhamento do desenvolvimento pedagógico', 'aspecpedago.php'),
(5, 'Acompanhamento do desenvolvimento pedagógico dos professores', 'aspecpedagoprof.php');

-- --------------------------------------------------------

--
-- Estrutura da tabela `respaluno`
--

CREATE TABLE `respaluno` (
  `id` int(11) NOT NULL,
  `cod_aluno` int(11) DEFAULT NULL,
  `cod_quest` int(11) DEFAULT NULL,
  `cod_aspec` int(11) DEFAULT NULL,
  `resposta` varchar(20) DEFAULT NULL,
  `obs` varchar(200) DEFAULT NULL,
  `encaminhamento` varchar(500) DEFAULT NULL,
  `informacoes` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `respaluno`
--

INSERT INTO `respaluno` (`id`, `cod_aluno`, `cod_quest`, `cod_aspec`, `resposta`, `obs`, `encaminhamento`, `informacoes`) VALUES
(105, 1, 3, 1, '1', '', '', ''),
(106, 1, 3, 2, '3', '', '', ''),
(107, 1, 3, 3, '2', '', '', ''),
(108, 1, 3, 4, '4', '', '', ''),
(109, 1, 3, 5, '1', '', '', ''),
(110, 1, 3, 6, '5', '', '', ''),
(111, 1, 3, 1, '1', '', '', ''),
(112, 1, 3, 2, '3', '', '', ''),
(113, 1, 3, 3, '2', '', '', ''),
(114, 1, 3, 4, '4', '', '', ''),
(115, 1, 3, 5, '1', '', '', ''),
(116, 1, 3, 6, '5', '', '', ''),
(117, 1, 3, 1, '0', '', '', ''),
(118, 1, 3, 2, '0', '', '', ''),
(119, 1, 3, 3, '0', '', '', ''),
(120, 1, 3, 4, '0', '', '', ''),
(121, 1, 3, 5, '0', '', '', ''),
(122, 1, 3, 6, '0', '', '', ''),
(123, 1, 2, 27, '1', '', '', ''),
(124, 1, 2, 28, '0', '', '', ''),
(125, 1, 2, 29, '0', '', '', ''),
(126, 1, 2, 30, '0', '', '', ''),
(127, 1, 2, 31, '0', '', '', ''),
(128, 1, 2, 32, '0', '', '', ''),
(129, 1, 2, 33, '0', '', '', ''),
(130, 1, 2, 34, '0', '', '', ''),
(131, 1, 2, 35, '5', '', '', ''),
(132, 1, 4, 36, '5', '', '', ''),
(133, 1, 4, 37, '0', '', '', ''),
(134, 1, 4, 38, '0', '', '', ''),
(135, 1, 4, 39, '0', '', '', ''),
(136, 1, 4, 40, '0', '', '', ''),
(137, 1, 4, 41, '0', '', '', ''),
(138, 1, 4, 42, '0', '', '', ''),
(139, 1, 4, 43, '0', '', '', ''),
(140, 1, 4, 44, '0', '', '', ''),
(141, 1, 4, 45, '0', '', '', ''),
(142, 1, 4, 46, '0', '', '', ''),
(143, 1, 4, 47, '0', '', '', ''),
(144, 1, 4, 48, '0', '', '', ''),
(145, 1, 4, 49, '0', '', '', ''),
(146, 1, 4, 50, '0', '', '', ''),
(147, 1, 4, 51, '0', '', '', ''),
(148, 1, 4, 52, '1', '', '', ''),
(149, 1, 5, 53, '2', '', '', ''),
(150, 1, 5, 54, '0', '', '', ''),
(151, 1, 5, 55, '0', '', '', ''),
(152, 1, 5, 56, '0', '', '', ''),
(153, 1, 5, 57, '0', '', '', ''),
(154, 1, 5, 58, '0', '', '', ''),
(155, 1, 5, 59, '0', '', '', ''),
(156, 1, 5, 60, '0', '', '', ''),
(157, 1, 5, 61, '0', '', '', ''),
(158, 1, 5, 62, '2', '', '', ''),
(159, 1, 1, 7, '3', '', '', ''),
(160, 1, 1, 8, '0', '', '', ''),
(161, 1, 1, 9, '0', '', '', ''),
(162, 1, 1, 10, '0', '', '', ''),
(163, 1, 1, 11, '0', '', '', ''),
(164, 1, 1, 12, '0', '', '', ''),
(165, 1, 1, 13, '0', '', '', ''),
(166, 1, 1, 14, '0', '', '', ''),
(167, 1, 1, 15, '0', '', '', ''),
(168, 1, 1, 16, '0', '', '', ''),
(169, 1, 1, 17, '0', '', '', ''),
(170, 1, 1, 18, '0', '', '', ''),
(171, 1, 1, 19, '0', '', '', ''),
(172, 1, 1, 20, '0', '', '', ''),
(173, 1, 1, 22, '0', '', '', ''),
(174, 1, 1, 23, '0', '', '', ''),
(175, 1, 1, 24, '0', '', '', ''),
(176, 1, 1, 25, '0', '', '', ''),
(177, 1, 1, 26, '3', '', '', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `cargo` varchar(50) DEFAULT NULL,
  `disciplina` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `user`, `pass`, `cargo`, `disciplina`) VALUES
(1, 'Dawid', 'dc5a2867505a9fc0ffea5842ee431279', 'professor', 'a');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users_adm`
--

CREATE TABLE `users_adm` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `users_adm`
--

INSERT INTO `users_adm` (`id`, `username`, `pass`) VALUES
(2, 'dawid', 'dc5a2867505a9fc0ffea5842ee431279'),
(3, 'vanessavitoria', '7472ecbd23035919ce77c9ea20727d74'),
(4, 'larasts', '3b07c768071e6175ced9ea12764baf2c');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aluno`
--
ALTER TABLE `aluno`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aspec`
--
ALTER TABLE `aspec`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_cod` (`fk_cod`);

--
-- Indexes for table `quest`
--
ALTER TABLE `quest`
  ADD PRIMARY KEY (`cod`);

--
-- Indexes for table `respaluno`
--
ALTER TABLE `respaluno`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cod_aluno` (`cod_aluno`),
  ADD KEY `cod_quest` (`cod_quest`),
  ADD KEY `cod_aspec` (`cod_aspec`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_adm`
--
ALTER TABLE `users_adm`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aluno`
--
ALTER TABLE `aluno`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `respaluno`
--
ALTER TABLE `respaluno`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=178;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users_adm`
--
ALTER TABLE `users_adm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `aspec`
--
ALTER TABLE `aspec`
  ADD CONSTRAINT `aspec_ibfk_1` FOREIGN KEY (`fk_cod`) REFERENCES `quest` (`cod`);

--
-- Limitadores para a tabela `respaluno`
--
ALTER TABLE `respaluno`
  ADD CONSTRAINT `respaluno_ibfk_1` FOREIGN KEY (`cod_aluno`) REFERENCES `aluno` (`id`),
  ADD CONSTRAINT `respaluno_ibfk_2` FOREIGN KEY (`cod_quest`) REFERENCES `quest` (`cod`),
  ADD CONSTRAINT `respaluno_ibfk_3` FOREIGN KEY (`cod_aspec`) REFERENCES `aspec` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
