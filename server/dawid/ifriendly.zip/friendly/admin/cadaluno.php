<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Friendly</title>
		<link rel="stylesheet" href="../css/estilodapag.css">
	</head>
	<body>
			<header>
				<label style="margin-left:15px">Friendly</label>
			</header>   
			<div id="menu">
				<div id="perfil"><img src="../img/koala.jpg" width="70px" height="70px" style="border-radius:28px"></div>
				<p style="font-size:20px"><a href="adm.php">Adm</a></p>
				<p><a href="cadaluno.php">CADASTRAR ALUNO</a></p>
				<p><a href="cadastro.php">CADASTRAR USUARIO</a></p>
				<p><a href="cadquest.php">CADASTRAR QUESTÕES</a></p>
				<p><a href="obsaval.php">OBSERVAR AVALIAÇÕES</a></p>
				<p><a href="obsdes.php">OBSERVAR DESEMPENHO</a></p>
				<p><a href="?func=sair">SAIR</a></p>
			</div>
			<div id="titulo">
			<h1 style="margin-left:15px">Cadastrar Aluno</h1>
			</div>
		<div id="conteudo">
			<p>
				<form>
					Nome:<input type="text">
					<br>
					<br>
					Matricula:<input type="text">
					<br>
					<br>
					"O que mais???"
					<br>
					<br>
					<input type="submit" value="Cadastrar">
				</form>
			</p>
		</div>
	</body>
</html>