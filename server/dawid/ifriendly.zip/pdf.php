<?php
  // include autoloader
    session_start();
    use Dompdf\Dompdf;

    require_once 'dompdf/autoload.inc.php';
    include "connection.php";

    $cargo = $_SESSION['cargo'];
    $disciplina = $_SESSION['disciplina'];
    $nomeP = $_SESSION['username'];
    // $conteudo = "<style>table tr, table tr td{border: 1px solid black;}table{text-align:center;width:100%;border-collapse:collapse;}</style>";
    // $conteudo .= "<table style='border: 1px solid black'>";
    // $conteudo .= "<tr>";
    // $conteudo .= "<th>Título $cargo $disciplina</th>";
    // $conteudo .= "<th>Nota (Grau de Intensidade)</th>";
    // $conteudo .= "</tr>";
    //
		 $al = $_POST['alun'];
    // $q = $mysqli->query("SELECT * from aluno where nome = '$al';");
    // $r = $q->fetch_array();
    // $h = $r['id'];
		// $query = $mysqli->query("SELECT * from respaluno r inner join aspec a on r.cod_aspec=a.id where r.cod_aluno='$h';");
		// $row = $query->num_rows;
    //   while ($a = $query->fetch_array()) {
    //     $conteudo .= '<tr><td>'.$a['titulo']."</td><td>".$a['resposta']."</td></tr>";
    //   }
    //
    // $conteudo .= "</table>";

    //parte2
    $t = "<img src='img/LOGOifriendly.png' alt='ifriendly' style='margin-top: -30px;width:140px;position:absolute;'>";
    $t .= "<div style='font-size: 14px;font-family: sans-serif;font-weight: 600;width:100%;text-align:center;'><img src='img/brasao.jpg' alt='brasao' style='width: 75px;'>";
    $t .= "<br>SERVIÇO PÚBLICO FEDERAL<br>
            Ministério da Educação<br>
            Secretaria de Educação Profissional e Tecnológica<br>
            Instituto Federal de Alagoas<br>
            Campus Arapiraca<br>
            Direção Geral<br>
            Departamento Acadêmico<br>
            Coordenação de Informática<br><br>
";
    $t .= "</div>";
    $t .= "<fieldset><legend>Informações do ".ucwords($cargo)."</legend>";
    $t .= "<table style='width:100%;'>";
    $t .= "<tr><td>Nome: ".ucwords($nomeP)."</td>";
    $t .= "<td>Cargo: ".ucwords($cargo)."</td>";
    $t .= "<td>Disciplina: ".ucwords($disciplina)."</td>";
    $t .= "</tr></table></fieldset><br>";
    $t .= "<fieldset><legend>Informações do Aluno</legend>";
    $t .= "<label>Nome: ".ucwords($al)."</label>";
    $t .= "</fieldset>";

    $dompdf = new DOMPDF();

    $dompdf->load_html('
        <p>'.$t.'</p>
    ');

    $dompdf->setPaper('A4', 'portrait');

    $dompdf->render();

    $dompdf->stream("$al.pdf",array("Attachment"=>false)); //para realizar Download basta alterar para true
 ?>
