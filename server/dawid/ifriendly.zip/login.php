<?php
	include ("connection.php");
	session_start();
	if(isset($_SESSION['logado']) && $_SESSION['logado']){
		header("Location: index.php");
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Friendly</title>
		<style>
			body{
				color: white;
				background-color:#00BCD4;
			}
			#login{
				float:left;
				background-color: white;
				color:gray;
				width:400px;
				height:600px;
				margin-left:2em;
				margin-top:2em;
				border-radius:25px;

			}
			form{
				position:relative;
				top:60px;
				left:95px;
			}
			#titulo{
				float: right;
				width:860px;
				height:600px;

			}
		</style>
	</head>
	<body>
		<div id="login">
			<br>
			<p style="font-size:30px; text-align:center">Login</p>
			<form action="" method="post">
				<label>Login:</label>
				<input type="text" name="log" size="20" id="log" required>
				<br>
				<br>
				<label>Senha:</label>
				<input type="password" name="pswd" id="pswd" required>
				<br>
				<br>
				<input type="submit" name="entrar" value="Entrar">
			</form>
		</div>
		<div id="titulo">
			<p><img style="width: 195px;" src="img/LOGOifriendly.png" alt="IFriendly"></p>
			<p style="font-size:26px">Sistema web de acompanhamento do desenvolvimento de alunos com transtorno do expectro autista - TEA</p>
		</div>
	</body>
</html>

<?php
	if(isset($_POST['entrar'])){
		$nome = mysqli_real_escape_string($mysqli, $_POST['log']);
		$pass = mysqli_real_escape_string($mysqli, md5($_POST['pswd']));
		$sql = $mysqli->query("SELECT * from users where user='$nome' AND pass='$pass';");
		$row = $sql->num_rows;
		$sr = $sql->fetch_assoc();
			if($row > 0){
				session_start();
				$_SESSION['username'] = $nome;
				$_SESSION['logado'] = true;
				$_SESSION['cargo'] = $sr['cargo'];
				$_SESSION['disciplina'] = $sr['disciplina'];
				header("Location: index.php");
				}else{
			echo "<script>alert('Usuario ou senha está incorreto');location.href='login.php';</script>";

		}
	}

?>
