<?php
	include("connection.php");
	error_reporting(false);
	session_start();
	if(!isset($_SESSION['logado']) || !$_SESSION['logado']){
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>IFriendly</title>
		<link rel="stylesheet" href="css/estilodapag.css">
		<script src="js/page.js"></script>
	</head>
	<body>
			<header>
				<div id="m" onclick="aparecer()">
				</div>
				<label>IFriendly</label>
			</header>
			<div id="menu">
				<div id="perfil"><img src="img/perfil.jpg"></div>
				<ul>
					<li><a href="index.php?func=perfil"><?php
						if($_SESSION['username']!=""){
							echo ucwords($_SESSION['username']);
						}else{
							echo "Não encontrado";
						}
					?></a></li>
					<li><a href="quest.php">QUESTIONÁRIOS</a></li>
					<li><a href="desempenho.php">DESEMPENHO</a></li>
					<li><a href="index.php?func=sair">SAIR</a></li>
				</ul>
			</div>
			<div id="titulo">
			<h1>Acompanhamento do desenvolvimento comportamental</h1>
			</div>
			<div id="conteudo">
				<div id="cntd">
					<form id="quests" action="" method="post">
						<label>Selecione o aluno: </label>
						<select name="nomeAluno">
							<?php
								$q = $mysqli->query("SELECT * from aluno order by nome;");
								$r = $q->num_rows;
								if($r>0){
									while($a = $q->fetch_array()){
							 ?>
							<option value="<?=$a['nome']?>"><?=$a['nome']?></option>
							<?php
									}
								}
							 ?>
						</select>
						<table>
						<thead>
							<th>Aspecto Comportamental</th>
							<th>Nota</th>
							<th>Observação</th>
							<th>Encaminhamento(os)</th>
						</thead>
						<tbody>
							<?php
								$q1 = $mysqli->query("SELECT * from aspec where fk_cod=2 order by id;");
								$r1 = $q1->num_rows;
								if($r1>0){
									while($a1 = $q1->fetch_array()){
							 ?>
							<tr>
								<td><?=$a1['titulo']?></td>
								<td><input type="number" style="text-align: center;" name="resposta<?=$a1['id']?>" onchange="this.title=this.value"  value="0" min="0" max="5" required></td>
								<td><input type="text" name="obs<?=$a1['id']?>" value="" ></td>
								<td><input type="text" name="enc<?=$a1['id']?>" value="" ></td>
							</tr>
							<?php
									}
								}
							 ?>
						</tbody>
					</table>
					<br><b>Informações complementares:</b><br>
							<textarea name="informacoes" rows="5" cols="120"></textarea>
					<br><br>
					<input type="submit" name="enviar" value="Enviar">
				</form>
			</div>
		</div>
	</body>
</html>
<?php
	if (isset($_POST['enviar'])) {
		$s = array();
		$nomeAluno = mysqli_real_escape_string($mysqli,$_POST['nomeAluno']);
		$query = $mysqli->query("SELECT * from aspec where fk_cod=2;");
		$row = $query->num_rows;

		while ($y = $query->fetch_array()) {
			array_push($s,$y['id']);
		}
		$respostas = array();
		$obs = array();
		$enc = array();
		for ($i=0; $i <= $row; $i++) {
			array_push($respostas,$_POST['resposta'.$s[$i]]);
			array_push($obs,$_POST['obs'.$s[$i]]);
			array_push($enc,$_POST['enc'.$s[$i]]);
		}
		$info = mysqli_real_escape_string($mysqli, $_POST['informacoes']);
		$query1 = $mysqli->query("SELECT * from aluno where nome = '$nomeAluno';");
		while ($c = $query1->fetch_array()) {
			$b = $c['id'];
		}

		for ($i=0; $i <= $row; $i++) {
			$o = $i;
			$ins = $mysqli->query("INSERT into respaluno (cod_aluno,cod_quest,cod_aspec,resposta,obs,encaminhamento,informacoes) values ($b,2,$s[$i],'$respostas[$o]','$obs[$o]','$enc[$o]','$info');");
		}
	}
 ?>
