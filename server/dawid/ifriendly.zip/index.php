<?php
	include("connection.php");
	session_start();
	if(!isset($_SESSION['logado']) || !$_SESSION['logado']){
		header("Location: login.php");
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>IFriendly</title>
		<link rel="stylesheet" href="css/estilodapag.css">
		<script src="js/page.js"></script>
		</head>
		<body>
			<header>
				<div id="m" onclick="aparecer()">
				</div>
				<label><a href="index.php">IFriendly</a></label>
			</header>
			<div id="menu">
				<div id="perfil"><img src="img/perfil.jpg"></div>
				<ul>
					<li><a href="index.php?func=perfil"><?php
						if($_SESSION['username']!=""){
							echo ucwords($_SESSION['username']);
						}else{
							echo "Não encontrado";
						}
					?></a></li>
					<li><a href="quest.php">QUESTIONÁRIOS</a></li>
					<li><a href="desempenho.php">DESEMPENHO</a></li>
					<li><a href="index.php?func=sair">SAIR</a></li>
				</ul>
			</div>
			<?php
				if (isset($_GET['func'])) {
					$pag = $_GET['func'];
					include $pag.".php";
				}
			 ?>

	</body>
</html>
