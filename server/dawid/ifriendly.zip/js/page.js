function aparecer(){
  var ap = document.getElementById('menu').style.display;
  if(ap==""){
    document.getElementById('menu').style.display='block';
    document.getElementById('menu').style.width='250px';
    document.getElementById('titulo').style.left='250px';
  }else  if(ap=="block"){
    document.getElementById('menu').style.display='';
  }
}
var slider = document.getElementById("myRange");
var output = document.getElementById("demo");
output.innerHTML = slider.value;

slider.oninput = function() {
  output.innerHTML = this.value;
}
