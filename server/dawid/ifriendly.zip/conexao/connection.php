<?php
  $host = "127.0.0.1";
  $user = "root";
  $pass = "wid123";
  $db = "ifriendly";

  $mysqli = new mysqli($host,$user,$pass,$db);

 ?>
