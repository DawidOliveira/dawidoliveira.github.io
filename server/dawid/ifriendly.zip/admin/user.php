<table>
  <tr>
    <th>ID</th>
    <th>Usuário</th>
    <th>Senha</th>
  </tr>
  <?php
    $q1 = $mysqli->query("SELECT * from users order by user;");
    $r1 = $q1->num_rows;
    if ($r1>0) {
      while ($a = $q1->fetch_array()) {
   ?>
  <tr>
    <td><?=$a['id']?></td>
    <td><?=$a['user']?></td>
    <td><?=$a['pass']?></td>
  </tr>
  <?php
      }
    }else{
      ?>
        <tr>
          <td></td>
          <td>Sem dados!</td>
          <td></td>
        </tr>
      <?php
    }
   ?>
</table>
