<h2>Cadastro de usuários</h2>
<form id="form" action="" method="post">
  <input type="text" name="name" placeholder="Usuário" required autofocus><br>
  <input type="password" name="pass" placeholder="Senha" required><br>
  <input type="password" name="cpass" placeholder="Confirme sua senha" required><br>
  <input type="submit" name="cad" value="Cadastrar">
</form>

<?php
  if (isset($_POST['cad'])) {
    $name = mysqli_real_escape_string($mysqli, $_POST['name']);
    $pass = mysqli_real_escape_string($mysqli, md5($_POST['pass']));
    $cpass = mysqli_real_escape_string($mysqli, md5($_POST['cpass']));

    if ($pass == $cpass) {
      $q2 = $mysqli->query("SELECT * from users where user='$name';");
      $r2 = $q2->num_rows;

      if ($r2>0) {
        echo "<script>alert('Usuário já está cadastrado!');</script>";
      }else{
        $i = $mysqli->query("INSERT into users (user, pass) values ('$name','$pass');");
        if ($i) {
          echo "<script>alert('Cadastrado com sucesso!');location.href='?func=adduseradm';</script>";
        }else{
          echo "<script>alert('Erro ao cadastrar!');</script>";

        }
      }
    }else{
      echo "<script>alert('Verifique se as senhas digitadas são iguais!');</script>";
    }

  }
 ?>
