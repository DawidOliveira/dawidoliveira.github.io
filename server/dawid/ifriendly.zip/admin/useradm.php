<table>
  <tr>
    <th>ID</th>
    <th>Usuário</th>
    <th>Senha</th>
  </tr>
  <?php
    $q1 = $mysqli->query("SELECT * from users_adm order by username;");
    $r1 = $q1->num_rows;
    if ($r1>0) {
      while ($a = $q1->fetch_array()) {
   ?>
  <tr>
    <td><?=$a['id']?></td>
    <td><?=$a['username']?></td>
    <td><?=$a['pass']?></td>
  </tr>
  <?php
      }
    }else{
      ?>
        <tr>
          <td></td>
          <td>Sem dados!</td>
          <td></td>
        </tr>
      <?php
    }
   ?>
</table>
