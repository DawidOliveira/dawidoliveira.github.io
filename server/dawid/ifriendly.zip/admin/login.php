<?php
	include "conexao/connection.php";
	error_reporting(false);
	session_start();
	if(isset($_SESSION['logado_adm']) && $_SESSION['logado_adm']){
		header("Location: index.php");
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Login - Painel de Controle</title>
		<meta charset="utf-8">
		<link href="css/style.css" rel="stylesheet">
	</head>
	<body>
		<form id="formLogin" action="" method="post">
			<!--<img src="" alt="">-->
			<h2>Login</h2>
			<input type="text" name="name" placeholder="Seu nome" autofocus required><br>
			<input type="password" name="pass" placeholder="Sua senha" required><br>
			<input type="submit" name="acessar" value="Acessar">
		</form>
	</body>
</html>

<?php
	if(isset($_POST['acessar'])){
		$pass = mysqli_real_escape_string($mysqli,md5($_POST['pass']));
		$user = mysqli_real_escape_string($mysqli,$_POST['name']);
		$q = $mysqli->query("SELECT * from users_adm where username='$user' and pass='$pass'");
		$r = $q->num_rows;
		if($r>0){
			session_start();
			$_SESSION['logado_adm']=TRUE;
			$_SESSION['user_adm']=ucwords($user);
			header("Location: index.php");
		}else{
			echo "<script>alert('Usu�rio ou senha incorreto!');</script>";
		}
	}
?>
