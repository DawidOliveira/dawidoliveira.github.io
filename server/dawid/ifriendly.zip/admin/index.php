<?php
	error_reporting(false);
	include "conexao/connection.php";
	session_start();
	if(!isset($_SESSION['logado_adm']) || !$_SESSION['logado_adm']){
		header("Location: login.php");
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Principal - Painel de Controle</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/style.css">
		<style>
			body{
				background-color: #ccc;
			}
			#form{
				display: block;
				margin: 1em auto;
				width: 40%;
				text-align: left;
				background-color: #F5F5F5;
				border-radius: 5px;
				padding: 10px;
			}

			#form input:focus{
				outline: 0 none;
			}

			#form input{
				margin: 5px 8px;
				border: none;
				background-color: inherit;
				border-bottom: 1px solid #ddd;
				padding: 6px;
				font-size: 14px;
				width: 60%;
			}

			#form input[type="submit"]{
				margin-left: 2%;
				border: none;
				background-color: white;
				width: 75px;
				cursor: pointer;
			}
		</style>
	</head>
	<body>
		<header>
			<div id="cabeca">
				<h2>IFriendly</h2>
			</div>
			<nav>
				<ul>
					<a href="?func=user"><li>U</li></a>
					<a href="?func=adduser"><li>AU</li></a>
					<a href="?func=useradm"><li>UA</li></a>
					<a href="?func=adduseradm"><li>AUA</li></a>
					<a href="?func=questionary"><li>Q</li></a>
					<a href="?func=logout"><li>S</li></a>
				</ul>
			</nav>
		</header>
		<div class="conteudo">
			<?php
				if (isset($_GET['func'])) {
					$pag = $_GET['func'];
					include $pag.".php";
				}
			 ?>
		</div>
	</body>
</html>
