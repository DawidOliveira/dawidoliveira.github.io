<?php
	error_reporting(false);
	session_start();
 ?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<title>Corretor On-Line</title>
		<meta charset="utf-8">
		<link href="css/style.css" rel="stylesheet">
		<style>
			<?php
				if(isset($_SESSION['fontes']) && isset($_SESSION['alinhamento']) && isset($_SESSION['cores'])){
					?>
					.pa{
						font-size: <?=$_SESSION['fontes']."px"?>; 
						text-align: <?=$_SESSION['alinhamento']?>; 
						color: <?=$_SESSION['cores']?>
					}
					<?php
				}
			?>
		</style>
	</head>
	<body>
		<?php require "header.php"; ?>
		<div class="conteudo">
			<?php
				if (isset($_REQUEST['func'])) {
					$pag = $_GET['func'];
					include "$pag".".php";
				}
			?>
		</div>

	</body>
</html>
