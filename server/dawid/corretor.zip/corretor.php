<span>Bem vindo, <?php echo $_SESSION['user']; ?></span>

<form action="" method="post">
  <fieldset  style="width: 800px;"><legend><span class="mudc" style="font-size: 1.5em;">Insira seu texto</span></legend>
    <textarea required name="texto" style="font-family: arial;min-height:200px; max-height: 200px; min-width: 800px; max-width: 800px;"></textarea><br>
    <label>Tamanho da fonte: </label>
    <select name="fontes">
      <option value="12">12PX</option>
      <option value="16">16PX</option>
      <option value="20">20PX</option>
    </select>
    <label>Alinhamento: </label>
    <select name="alinhamento">
      <option value="center">centralizado</option>
      <option value="right">à direita</option>
      <option value="left">à esquerda</option>
    </select>
    <label>Cor: </label>
    <input type="color" name="cores"><br>
    <input type="submit" name="enviar" value="FORMATAR">
  </fieldset>
</form>

<?php
  if (isset($_POST['enviar'])) {
    $_SESSION['fontes'] = $_POST['fontes'];
    $_SESSION['alinhamento'] = $_POST['alinhamento'];
    $_SESSION['cores'] = $_POST['cores'];
    $_SESSION['text']=$_POST['texto'];

    header("Location: index.php?func=resultado_corretor");
  }

 ?>
