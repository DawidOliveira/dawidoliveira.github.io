<header>
	<h2><a href="index.php"><span class="mudc">Corretor</span> On-Line</a></h2>
	<ul>
		<a href="<?php echo (isset($_SESSION['user']) && !empty($_SESSION['user']))?'index.php?func=corretor':'index.php?func=login'; ?>"><li><?php if (isset($_SESSION['user']) && !empty($_SESSION['user'])) {
			echo strtoupper($_SESSION['user']);
		}else{
			echo "LOGIN";
		} ?></li></a>
		<a href="<?php echo (isset($_SESSION['user']) && !empty($_SESSION['user']))?'index.php?func=corretor':'index.php?func=login'; ?>"><li style="border-left: 1px solid #ccc;border-right: 1px solid #ccc;">CORRETOR</li></a>
		<a href="index.php?func=logout"><li>LOGOUT</li></a>
	<ul>
</header>
