<form action="" method="post">
  <fieldset><legend>LOGIN</legend>
    <label>Usuário:</label>
    <select name="usuarios" autofocus>
      <option>Selecione um usuário...</option>
      <option value="dawid" name="dawid">Dáwid Oliveira</option>
      <option value="raiela" name="raiela">Raiela Quirino</option>
      <option value="lucas" name="lucas">Lucas Victor</option>
      <option value="gabriel" name="gabriel">Gabriel Nunes</option>
      <option value="giovanna" name="giovanna">Giovanna Fonseca</option>
      <option value="ana" name="ana">Ana Kalorina</option>
    </select><br><br>
    <label>Senha:</label>
    <input type="password" name="pass"><br><br>
    <input type="submit" name="enviar">
  </fieldset>
</form>

<?php
  //$_session['user']
  if (isset($_POST['enviar'])) {
    $usuario = ucwords($_POST['usuarios']);
    $senha = "";
    switch ($usuario) {
      case 'Dawid':
        $senha = "wid123";
        break;

      case 'Raiela':
        $senha = "rai123";
        break;

      case 'Lucas':
        $senha = "luc123";
        break;

      case 'Gabriel':
        $senha = "gabriel18";
        break;

      case 'Giovanna':
        $senha = "hipopotamoeh10";
        break;

      case 'Ana':
        $senha = "karol123";
        break;

      default:
        echo "<script>alert('Usuário incorreto!');location.href='index.php?func=login'</script>";
        break;
    }
    if ($_POST['pass']==$senha) {
      session_start();
      $_SESSION['user']=$usuario;
      header("Location: index.php?func=corretor");
    }
  }

 ?>
