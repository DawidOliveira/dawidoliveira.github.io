<h2>Seu texto formatado:</h2>
<div class="res">
  <p class="pa"><?=$_SESSION['text']?></p>
</div>
<form action="" method="post">
  <label>Digite seu email:</label>
  <input type="text" name="email" required>
  <input type="submit" name="enviar" value="ENVIAR POR EMAIL">
</form>

<?php
	if(isset($_POST['enviar'])){
		$to = $_POST['email'];
		$assunto = "Texto formatado";
		$msg=$_SESSION['text'];
		$mensagem = "<p class="."pa".">$msg</p>";
		$header = "Content-Type: text/html; charset = utf-8\n". "From: dawidoliveira2@gmail.com\n";
		$enviado = mail($to,$assunto,$mensagem,$header);
		var_dump($enviado);
	}
?>
