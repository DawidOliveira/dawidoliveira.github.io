<?php
  include "conexao/connection.php";
  session_start();
  if (!isset($_SESSION['user_adm']) || empty($_SESSION['user_adm'])) {
    header("Location: login.php");
  }
 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Painel de Controle - Inicial</title>
    <link rel="stylesheet" href="css/estilo.css">
  </head>
  <body>
    <header>
      <h2>IFriendly</h2>
    </header>
    <nav>
      <ul>
        <li><a target="_new" href="../index.php">Ir para o site</a></li>
        <li><a href="index.php?func=users">Usuários</a></li>
        <li><a href="index.php?func=adduser">Add Usuário</a></li>
        <li><a href="index.php?func=logout">Sair (<?php echo ucwords($_SESSION['user_adm']);?>)</a></li>
      </ul>
    </nav>
    <div class="conteudo">
      <?php
        if (isset($_GET['func'])) {
          $pag = $_GET['func'];
          include "$pag".'.php';
        }
       ?>
    </div>
  </body>
</html>
