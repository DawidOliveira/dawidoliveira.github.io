<form action="" method="post">
  <label>Username: </label><br>
  <input type="text" name="username" placeholder="O nome utilizado para fazer login" required autofocus><br>
  <label>Nome completo:</label><br>
  <input type="text" name="name" required><br>
  <label>Email:</label><br>
  <input type="email" name="email" required><br>
  <label>Telefone:</label><br>
  <input type="tel" name="tel" required><br>
  <label>Senha:</label><br>
  <input type="password" name="pass" required><br>
  <label>Confirme sua senha:</label><br>
  <input type="password" name="cpass" required><br>
  <input type="submit" name="add" value="Adicionar usuário">
</form>

<?php
  if (isset($_POST['add'])) {
    $username = mysqli_real_escape_string($mysqli,$_POST['username']);
    $name = mysqli_real_escape_string($mysqli,$_POST['name']);
    $email = mysqli_real_escape_string($mysqli,$_POST['email']);
    $tel = mysqli_real_escape_string($mysqli,$_POST['tel']);
    $pass = mysqli_real_escape_string($mysqli,$_POST['pass']);
    $cpass = mysqli_real_escape_string($mysqli,$_POST['cpass']);
    if ($pass == $cpass) {
      $q = $mysqli->query("INSERT into users (username,name,pass,tel,email) values ('$username','$name','$pass','$tel','$email');");

      if ($q) {
        echo "<script>alert('Adicionado com sucesso!');</script>";
        header("Location: index.php?func=adduser");
      }else{
        echo "<script>alert('Erro ao adicionar!');</script>";
      }
    }

  }
 ?>
