<?php
  $host = "localhost";
  $user = "root";
  $pass = "";
  $db = "ifriendly";

  $mysqli = new mysqli($host, $user, $pass, $db);
 ?>
