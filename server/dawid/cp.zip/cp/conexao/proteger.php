<?php
  function prot(){
    if ($_SESSION['user_adm']!=""){
      header("Location: index.php");
    }else{
      header("Location: login.php");
    }
  }
 ?>
