<table>
  <tr>
    <th>ID</th>
    <th>Username</th>
    <th>Nome Completo</th>
    <th>E-mail</th>
    <th>Senha</th>
    <th>Telefone</th>
  </tr>
  <?php
    $q = $mysqli->query("SELECT * from users order by id");
    $r = $q->num_rows;
    while ($a = $q->fetch_array()) {
   ?>
  <tr>
    <td><?= $a['id'] ?></td>
    <td><?= $a['username'] ?></td>
    <td><?= $a['name'] ?></td>
    <td><?= $a['email'] ?></td>
    <td><?= $a['pass'] ?></td>
    <td><?= $a['tel'] ?></td>
  </tr>
  <?php } ?>
</table>
