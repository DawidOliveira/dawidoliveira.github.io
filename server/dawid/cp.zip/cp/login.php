<?php
  include "conexao/connection.php";
  session_start();
  if (isset($_SESSION['user_adm']) && !empty($_SESSION['user_adm'])) {
    header("Location: index.php");
  }
 ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Painel de Controle - Login</title>
  </head>
  <body>
    <form action="" method="post">
      <input type="text" name="user" required placeholder="Seu usuario"><br>
      <input type="password" name="pass" required placeholder="Sua senha"><br>
      <input type="submit" name="botao" value="Acessar">
    </form>
  </body>
</html>

<?php
  if (isset($_POST['botao'])) {
    $user = mysqli_real_escape_string($mysqli,$_POST['user']);
    $pass = mysqli_real_escape_string($mysqli,$_POST['pass']);
    $sql = $mysqli->query("SELECT * from users_adm where username='$user' and password='$pass';");
    $row = $sql->num_rows;
    if($row > 0){
      session_start();
      $_SESSION['user_adm'] = $user;
      header("Location: index.php");
    }else{
      echo "<script>alert('Usuario ou senha incorretos!');</script>";
      header("Location: login.php");
    }

  }
 ?>
