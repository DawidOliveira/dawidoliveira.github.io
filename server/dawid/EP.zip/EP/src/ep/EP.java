package ep;

import static java.lang.System.exit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Objects;
import javax.swing.JOptionPane;

public class EP {

    static int menu() {
        int x = Integer.parseInt(JOptionPane.showInputDialog("---------------------MENU---------------------\n"
                + "1) Fazer o rol;\n"
                + "2) Intervalo de classes;\n"
                + "3) Media: aritmética;\n"
                + "4) Moda;\n"
                + "5) Mediana;\n"
                + "6) Porcentagem;\n"
                + "7) Quartil;\n"
                + "8) Decil;\n"
                + "9) Percentil;\n"
                + "10) Variância;\n"
                + "11) Desvio padrão;\n"
                + "12) Coeficiente de variação;\n"
                + "13) Erro padrão;\n"
                + "14) Distribuição binomial;\n"
                + "15) Distribuição de Poisson;\n"
                + "16) Guarde os números para utilização das funções acima;\n"
                + "0) Sair.\n"
                + "Obs.: Digite o número da função!\n"
                + "Obs2.: Obrigatoriamente utilize a função 16!"));
        return x;
    }

    public static void main(String[] args) {
        Funcoes fc = new Funcoes();
        int x = 1;
        do {
            x = menu();
            switch (x) {
                case 1:
                    fc.rol();
                    JOptionPane.showMessageDialog(null, fc.getAl().toArray());
                    break;
                case 2:
                    fc.intervaloClasses();
                    break;
                case 3:
                    fc.media();
                    JOptionPane.showMessageDialog(null, "Média aritmética: " + fc.getMediaA());
                    break;
                case 4:
                    fc.moda();
                    break;
                case 5:
                    fc.mediana();
                    break;
                case 6:
                    fc.porcentagem();
                    break;
                case 7:
                    fc.quartil();
                    break;
                case 8:
                    fc.decil();
                    break;
                case 9:
                    fc.percentil();
                    break;
                case 10:
                    fc.variancia();
                    JOptionPane.showMessageDialog(null, "Variância: " + fc.getResultadoVar());
                    break;
                case 11:
                    fc.desvioPadrao();
                    JOptionPane.showMessageDialog(null, "Desvio Padrão: " + fc.getDesvPad());
                    break;
                case 12:
                    fc.coeficienteVariacao();
                    JOptionPane.showMessageDialog(null, "Coeficiente de Variação: " + fc.getCv() +"%");
                    break;
                case 13:
                    fc.erroPadrao();
                    break;
                case 14:
                    int ensaio = Integer.parseInt(JOptionPane.showInputDialog("Ensaios: "));
                    int sucesso = Integer.parseInt(JOptionPane.showInputDialog("Sucesso: "));
                    double pS = Double.parseDouble(JOptionPane.showInputDialog("Probabilidade de Sucesso: "));
                    JOptionPane.showMessageDialog(null,"Distribuição Binomial: \n\n"+fc.binomial(ensaio, sucesso, pS));
                    break;
                case 15:
                    double lambda = Double.parseDouble(JOptionPane.showInputDialog("Taxa média de ocorrência do evento:"));
                    int xk = Integer.parseInt(JOptionPane.showInputDialog("Probabilidade de ocorrerem exatamente quantos eventos?"));
                    JOptionPane.showMessageDialog(null,"Distribuição de Poisson: \n\n"+ fc.poissom(lambda, xk));
                    break;
                case 16:
                    fc.guardarNumeros();
                    break;
                case 0:
                    JOptionPane.showMessageDialog(null, "Volte logo", "Saindo...", 1);
                    exit(0);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "O número escolhido não está no menu!", "Erro", 0);

            }
        } while (x != 0);
    }

}
