package ep;

import java.util.ArrayList;
import java.util.Objects;
import javax.swing.JOptionPane;

public class Funcoes {

    private ArrayList<Double> al;
    private double mediaA = 0;
    private double resultadoVar = 0;
    private double desvPad = 0;
    private double cv = 0;
    private double poissom = 0;
    private double binom = 0;

    public Funcoes() {
        al = new ArrayList<>();
    }

    public double getMediaA() {
        return mediaA;
    }

    public void setMediaA(double mediaA) {
        this.mediaA = mediaA;
    }

    public ArrayList<Double> getAl() {
        return al;
    }

    public void setAl(ArrayList<Double> al) {
        this.al = al;
    }

    public void rol() {
        double aux = 0;
        for (int i = 0; i < al.size() - 1; i++) {
            for (int j = i + 1; j < al.size(); j++) {
                if (al.get(j) < al.get(i)) {
                    aux = al.get(j);
                    al.set(j, al.get(i));
                    al.set(i, aux);
                }
            }
        }

    }

    public void intervaloClasses() {
        rol();
        String all = null;
        int j = 0;
        double amax = 0,
                amin = 0;
        for (int i = 0; i < al.size(); i++) {
            if (i == 0) {
                amin = al.get(i);
            }
            if (i == al.size() - 1) {
                amax = al.get(i);
            }
        }
        int k = Integer.parseInt(JOptionPane.showInputDialog("Digite quantas classes deseja ter:"));
        double h = Math.ceil((amax - amin) / k);
        double aux = amin + h;
        while (j != k) {
            if (j == 0) {
                all = amin + "|----" + aux + "\n";
            } else {
                all += aux + "|----";
                aux += h;
                all += aux + "\n";
            }
            j++;
        }
        JOptionPane.showMessageDialog(null, all);
    }

    public void media() {
        rol();
        double total = al.size(),
                soma = 0;
        for (int i = 0; i < al.size(); i++) {
            soma += al.get(i);
        }
        mediaA = (soma / total);
    }

    public void moda() {
        rol();
        int count = 0,
                arm = 0;
        double num = 0;
        for (int i = 0; i < al.size(); i++) {
            for (int j1 = 0; j1 < al.size(); j1++) {
                if (Objects.equals(al.get(i), al.get(j1))) {
                    count++;
                } else {
                    if (count > arm) {
                        arm = count;
                        num = al.get(i);
                    }
                    count = 0;
                }
            }
        }
        JOptionPane.showMessageDialog(null, "A moda é: " + num);
    }

    public void mediana() {
        rol();
        double mediana = 0;
        int pos = (int) Math.floor(al.size() / 2);
        if (al.size() % 2 != 0) {
            mediana = al.get(pos);
        } else {
            mediana = (al.get(pos) + al.get(pos - 1)) / 2;
        }
        JOptionPane.showMessageDialog(null, "A mediana é: " + mediana);
    }

    public void porcentagem() {
        rol();
        double count1 = 0;
        String porc = "Porcentagem: \n\n";

        double valorp;
        int p = Integer.parseInt(JOptionPane.showInputDialog("Digite se você quer que seja:\n1) Maior;\n2) Menor;\n3) Igual\n a determinada porcentagem:"));
        switch (p) {
            case 1:
                valorp = Double.parseDouble(JOptionPane.showInputDialog("Maior que quantos %?"));
                for (int i = 0; i < al.size(); i++) {
                    if (i != 0) {
                        if (!Objects.equals(al.get(i), al.get(i - 1))) {
                            for (int j1 = 0; j1 < al.size(); j1++) {
                                if (Objects.equals(al.get(i), al.get(j1))) {
                                    count1++;
                                }
                            }
                            if ((count1 / al.size()) * 100 > valorp) {
                                porc += "si: " + al.get(i) + "\nfi: " + count1 + "\npi: " + (count1 / al.size()) * 100 + "%\n\n";
                            }
                        }

                    } else {
                        for (int j1 = 0; j1 < al.size(); j1++) {
                            if (Objects.equals(al.get(i), al.get(j1))) {
                                count1++;
                            }
                        }
                        if ((count1 / al.size()) * 100 > valorp) {
                            porc += "si: " + al.get(i) + "\nfi: " + count1 + "\npi: " + (count1 / al.size()) * 100 + "%\n\n";
                        }
                    }
                    count1 = 0;
                }
                break;
            case 2:
                valorp = Double.parseDouble(JOptionPane.showInputDialog("Menor que quantos %?"));
                for (int i = 0; i < al.size(); i++) {
                    if (i != 0) {
                        if (!Objects.equals(al.get(i), al.get(i - 1))) {
                            for (int j1 = 0; j1 < al.size(); j1++) {
                                if (Objects.equals(al.get(i), al.get(j1))) {
                                    count1++;
                                }
                            }
                            if ((count1 / al.size()) * 100 < valorp) {
                                porc += "si: " + al.get(i) + "\nfi: " + count1 + "\npi: " + (count1 / al.size()) * 100 + "%\n\n";
                            }
                        }

                    } else {
                        for (int j1 = 0; j1 < al.size(); j1++) {
                            if (Objects.equals(al.get(i), al.get(j1))) {
                                count1++;
                            }
                        }
                        if ((count1 / al.size()) * 100 < valorp) {
                            porc += "si: " + al.get(i) + "\nfi: " + count1 + "\npi: " + (count1 / al.size()) * 100 + "%\n\n";
                        }
                    }
                    count1 = 0;
                }
                break;
            case 3:
                valorp = Double.parseDouble(JOptionPane.showInputDialog("Igual a quantos %?"));
                for (int i = 0; i < al.size(); i++) {
                    if (i != 0) {
                        if (!Objects.equals(al.get(i), al.get(i - 1))) {
                            for (int j1 = 0; j1 < al.size(); j1++) {
                                if (Objects.equals(al.get(i), al.get(j1))) {
                                    count1++;
                                }
                            }
                            if ((count1 / al.size()) * 100 == valorp) {
                                porc += "si: " + al.get(i) + "\nfi: " + count1 + "\npi: " + (count1 / al.size()) * 100 + "%\n\n";
                            }
                        }

                    } else {
                        for (int j1 = 0; j1 < al.size(); j1++) {
                            if (Objects.equals(al.get(i), al.get(j1))) {
                                count1++;
                            }
                        }
                        if ((count1 / al.size()) * 100 == valorp) {
                            porc += "si: " + al.get(i) + "\nfi: " + count1 + "\npi: " + (count1 / al.size()) * 100 + "%\n\n";
                        }
                    }
                    count1 = 0;
                }
                break;
            default:
                JOptionPane.showMessageDialog(null, "Nenhuma opção escolhida!");
        }
        JOptionPane.showMessageDialog(null, porc);
    }

    public void quartil() {
        rol();
        double quartil = 0;
        int pos1 = (int) Math.floor(al.size() / 4);

        if (pos1 % 2 != 0) {
            quartil = al.get(pos1);
        } else {
            quartil = (al.get(pos1) + al.get(pos1 - 1)) / 2;
        }
        JOptionPane.showMessageDialog(null, "Quartil: " + quartil);
    }

    public void decil() {
        rol();
        
    }

    public void percentil() {
        rol();
    }

    public void variancia() {
        rol();
        media();
        double var = 0;

        for (int i = 0; i < al.size(); i++) {
            var += (al.get(i) - mediaA) * (al.get(i) - mediaA);
        }

        resultadoVar = var / al.size();

    }

    public void desvioPadrao() {
        rol();
        variancia();
        desvPad = Math.sqrt(resultadoVar);
    }

    public double getDesvPad() {
        return desvPad;
    }

    public void setDesvPad(double desvPad) {
        this.desvPad = desvPad;
    }

    public double getResultadoVar() {
        return resultadoVar;
    }

    public void setResultadoVar(double resultadoVar) {
        this.resultadoVar = resultadoVar;
    }

    public void coeficienteVariacao() {
        rol();
        desvioPadrao();
        cv = (desvPad / mediaA) * 100;
    }

    public double getCv() {
        return cv;
    }

    public void setCv(double cv) {
        this.cv = cv;
    }

    public void erroPadrao() {
        rol();
        desvioPadrao();
        double ep = desvPad / Math.sqrt(al.size());
        JOptionPane.showMessageDialog(null, "Erro Padrão: " + ep);
    }

    public void guardarNumeros() {
        double aux1;
        int qntd = Integer.parseInt(JOptionPane.showInputDialog("Quantos números?"));
        for (int i = 0; i < qntd; i++) {
            aux1 = Double.parseDouble(JOptionPane.showInputDialog("Digite o " + (i + 1) + "º valor:"));
            al.add(aux1);
        }
    }

    public double fatorial(double num) {
        if (num <= 1) {
            return 1;
        } else {
            return num * fatorial(num - 1);
        }
    }

    public double poissom(double lambda, int k) {
        poissom = ((1 / Math.pow(Math.E, lambda)) * Math.pow(lambda, k)) / fatorial(k);
        return poissom;
    }

    public double binomial(int n, int k, double prob) {
        binom = (fatorial(n) / fatorial(k) * fatorial(n - k)) * Math.pow(prob, k) * Math.pow(1 - prob, n - k);
        return binom;
        //n = ensaios; k = sucessos; prob = probabilidade de sucesso;
    }

}
