<!DOCTYPE html>

<html>
	<head>
		<title>Avaliacao</title>
		<meta charset="UTF-8">
		<style>
			*{
				margin:0;
				padding:0;
			}
			body{
				font-family: cursive;
				background-color: #ccc;
				overflow-x: hidden;
			}
			header{
				width: 100%;
				background-color: white;
				padding: 6px;
			}
			header h2{
				margin-left: 20%;
				font-size: 2em;
			}
			header h2 span{
				color: #00bb55;
			}
			.conteudo{
				display: block;
				width: 60%;
				margin: 1em auto;
			}
			.conteudo table{
				background-color: white;
				width: 100%;
				padding: 5px;
				margin-bottom: 30px;
			}
		</style>
	</head>
	<body>
		<header>
			<h2><span>Tec</span>Blog</h2>
		</header>
		<?php
			$usuario = "Fernando Antonio";
			$array[0]['titulo']='Intel lanca oitava geracao';
			$array[0]['data']='Postado em: 1 de Outubro de 2017';
			$array[0]['noticia']='oitava geracao de processadores da Intel tera tres arquiteturas diferentes, abrindo espaco para alguma confusao: Kaby Leke Refresh, Coffee Lake e Cannon Lake sao os nomes das tres linhas que serao lancadas ao longo dos proximos meses e que concentrarao os produtos da nova geracao de CPUs da marca.';
			$array[0]['autor']="Postado por: $usuario";
			
			$array[1]['titulo']='Novas placas-mae Gigabyte Aorus';
			$array[1]['data']='Postado em: 25 de Setembro de 2017';
			$array[1]['noticia']='A Gigabyte lancou oficialmente sua nova linha de placas-mae Aorus com chopset Z370 que chegam com tecnologia de alimentacai digital encontrada em servidores e suporte a memorias de ate 4133 MHz';
			$array[1]['autor']="Postado por: $usuario";
			
			$array[2]['titulo']='AMD RX500';
			$array[2]['data']='Postado em: 30 de Junho de 2017';
			$array[2]['noticia']='A AMD enfim lancou sua nova series de placa de video que ja conhecemos por causa de inumeros vazamentos. As novas Radeon RX500 trazem uma versao revisada da Polaris, com um certo ganho na performance, mas uma melhoria visivel na eficienciaenergetica e TDP.';
			$array[2]['autor']="Postado por: $usuario";
			
			$array[3]['titulo']='Novos processadores AMD';
			$array[3]['data']='Postado em: 23 de Maio de 2017';
			$array[3]['noticia']='Por muitos anos, a AMD viu a Intel disparar no mercado processadores para PCs, perdendo uma grande fatia do setor e ocupando um segundo lugar cada vez mais distante, ficando relegada a computadores menos potentes. O anuncio da nova linha de processadores Ryzen chega em um momento oportuno para tentar reduzir o vao entre as duas companhias.';
			$array[3]['autor']="Postado por: $usuario";
		?>
		<div class="conteudo">
			<?php
				foreach($array as $conteudo){
			?>
				<table>
					<tr><td style="color: #00bb55; font-size: 1.5em;"><?= $conteudo['titulo'] ?></td></tr>
					<tr><td style="font-size: 0.7em; margin-bottom: 15px;display: block;"><?= $conteudo['data'] ?></td></tr>
					<tr><td><?= $conteudo['noticia'] ?></td></tr>
					<tr><td><span style="color: #ddd;font-weight: bold;">|</span><?= $conteudo['autor'] ?></td></tr>
				</table>
				<?php
				}
				?>
		</div>
		
	</body>
</html>