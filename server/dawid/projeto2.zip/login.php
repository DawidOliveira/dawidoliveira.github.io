<?php
  error_reporting(false);
  include  "conexao/connection.php";
  session_start();
  if (isset($_SESSION['logado']) && $_SESSION['logado']) {
    header("Location: index.php");
  }
  if (isset($_SESSION['logado_adm']) && $_SESSION['logado_adm']){
	 header("Location: admin.php");
  }
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login - Loja de eletrodomésticos</title>
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <form class="formLogin" id="formLogin" action="" method="post"> <!-- FORMULÁRIO PRA LOGIN -->
      <!-- <img src="" alt=""> -->
      <h2>Login</h2>
      <label>Tipo de login: </label>
      <select name="tipo">
        <option value="user">Usuário normal</option>
        <option value="useradm">Usuário ADM</option>
      </select><br><br>
      <input type="text" name="name" placeholder="Usuário" required autofocus><br>
      <input type="password" name="pass" placeholder="Senha" required><br>
      <input type="submit" name="acessar" value="Acessar"><a href="?func=cad"> Não tem conta? <span style="color: #cca433;">Cadastre-se!</span></a>
    </form>
    <form class="formLogin" id="formCad" action="" method="post"> <!-- FORMULÁRIO PRA CADASTRO -->
      <!-- <img src="" alt=""> -->
      <label>Tipo de login: </label>
      <select name="tipo">
        <option value="user">Usuário normal</option>
        <option value="useradm">Usuário ADM</option>
      </select><br><br>
      <input type="text" name="nameCad" placeholder="Usuário" required autofocus><br>
      <input type="password" name="passCad" placeholder="Senha" required><br>
      <input type="password" name="passCadC" placeholder="Confirme sua senha" required><br>
      <input type="submit" name="cadastrar" value="Cadastrar"> <a href="login.php" style="font-size: 12px;">Voltar para login</a>
    </form>
  </body>
</html>

<?php
  if (isset($_POST['acessar'])) {
    $name = mysqli_real_escape_string($mysqli,$_POST['name']);
    $pass = mysqli_real_escape_string($mysqli,md5($_POST['pass']));
    $tipo = mysqli_real_escape_string($mysqli,$_POST['tipo']);
    if ($tipo == "user") {
      $query = $mysqli->query("SELECT * from users where username='$name' and password='$pass';");
      $row = $query->num_rows;
      if ($row>0) {
        session_start();
        $_SESSION['user']=ucwords($name);
        $_SESSION['logado']=true;
        header("Location: index.php");
      }else{
        echo "<script>alert('Usuário ou senha incorreto(a)!');</script>";
      }
    }else{
      $query = $mysqli->query("SELECT * from users_adm where username='$name' and password='$pass';");
      $row = $query->num_rows;
      if ($row>0) {
        session_start();
        $_SESSION['user_adm']=ucwords($name);
        $_SESSION['logado_adm']=true;
        header("Location: admin.php");
      }else{
        echo "<script>alert('Usuário ou senha incorreto(a)!');</script>";
      }
    }
  }
?>

<?php
  if (isset($_GET['func'])) {
    $pag = $_GET['func'];
	if($pag=='cad'){
		echo "<script>document.getElementById('formCad').style.display='block';</script>";
		echo "<script>document.getElementById('formLogin').style.display='none';</script>";
	}else{
		header("Location: login.php");
	}
  }
?>

<?php
  if (isset($_POST['cadastrar'])) {
    $nameCad = mysqli_real_escape_string($mysqli,$_POST['nameCad']);
    $passCad = mysqli_real_escape_string($mysqli,md5($_POST['passCad']));
    $passCadC = mysqli_real_escape_string($mysqli,md5($_POST['passCadC']));
    $tipo = mysqli_real_escape_string($mysqli,$_POST['tipo']);

    if ($passCad == $passCadC) {
      if ($tipo == "user") {
        $q = $mysqli->query("SELECT * from users where username = '$nameCad';");
        $r = $q->num_rows;
        if ($r>0) {
          echo "<script>alert('Usuário já cadastrado!');</script>";
        }else{
          $q1 = $mysqli->query("INSERT into users (username,password) values ('$nameCad','$passCad');");
          if ($q1) {
            echo "<script>alert('Usuário cadastrado com sucesso!');location.href='login.php';</script>";
          }else{
            echo "<script>alert('Erro ao cadastrar!');</script>";

          }
        }
      }else{
        $q2 = $mysqli->query("SELECT * from users_adm where username = '$nameCad';");
        $r2 = $q2->num_rows;
        if ($r2>0) {
          echo "<script>alert('Usuário já cadastrado!');</script>";
        }else{
          $q3 = $mysqli->query("INSERT into users_adm (username,password) values ('$nameCad','$passCad');");
          if ($q3) {
            echo "<script>alert('Usuário cadastrado com sucesso!');location.href='login.php';</script>";
          }else{
            echo "<script>alert('Erro ao cadastrar!');</script>";

          }
        }
      }
    }else{
		echo "<script>alert('As senhas não correspondem!')</script>";
	}
  }
?>
