<?php
  error_reporting(false);
  include "conexao/connection.php";
  session_start();
  if (!isset($_SESSION['logado_adm']) || !$_SESSION['logado_adm']) {
    header("Location: login.php");
  }
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Loja de Eletrodomésticos - Página ADM</title>
  </head>
  <body>

  </body>
</html>
