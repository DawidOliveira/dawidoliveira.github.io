<?php
  error_reporting(false);
  include "conexao/connection.php";
  session_start();
  if (!isset($_SESSION['logado']) || !$_SESSION['logado']) {
    header("Location: login.php");
  }
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Loja de Eletrodomésticos - Página Inicial</title>
  </head>
  <body>
    <?php session_destroy(); ?>
  </body>
</html>
