<?php
  $host = "localhost";
  $usuario = "root";
  $senha = "";
  $db = "controle";

  $mysqli = new mysqli($host,$usuario,$senha,$db);
?>
